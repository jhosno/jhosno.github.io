// images setup
// uniforms backgrounds color
const images = [
  "http://hmongouachon.com/_demos/rgbKineticSlider/color-01.jpg",
  "http://hmongouachon.com/_demos/rgbKineticSlider/color-02.jpg",
  "http://hmongouachon.com/_demos/rgbKineticSlider/color-03.jpg",
];

// content setup
const texts = [
  ["I watched the storm, so beautiful yet terrific."],
  ["Almost before we knew it, we had left the ground."],
  ["The recorded voice scratched in the speaker."],
]

rgbKineticSlider = new rgbKineticSlider({

  slideImages: images, // array of images > must be 1920 x 1080
  itemsTitles: texts, // array of titles / subtitles

  backgroundDisplacementSprite: 'http://hmongouachon.com/_demos/rgbKineticSlider/map-3.jpg', // slide displacement image 
  cursorDisplacementSprite: 'http://hmongouachon.com/_demos/rgbKineticSlider/map-7.jpg', // cursor displacement image 

  cursorImgEffect : true, // enable cursor img effect
  cursorTextEffect : true, // enable cursor text effect
  cursorScaleIntensity : 0.35, // cursor effect intensity
  cursorMomentum : 0.14, // lower is slower

  swipe: true, // enable swipe
  swipeDistance : window.innerWidth * 0.5, // swipe distance - ex : 580
  swipeScaleIntensity:5, // scale intensity during swipping

  slideTransitionDuration : 0.75, // transition duration
  transitionScaleIntensity : 80, // scale intensity during transition
  transitionScaleAmplitude : 100, // scale amplitude during transition

  nav: true, // enable navigation
  navElement: '.main-nav', // set nav class

  imagesRgbEffect : false, // enable img rgb effect
  // imagesRgbIntensity : 0.9, // set img rgb intensity
  // navImagesRgbIntensity : 80, // set img rgb intensity for regular nav

  textsDisplay : true, // show title
  textsSubTitleDisplay : false, // show subtitles
  textsTiltEffect : true, // enable text tilt
  googleFonts : ['Poppins:700', ''], // select google font to use
  buttonMode : true, // enable button mode for title
  textsRgbEffect : true, // enable text rgb effect
  textsRgbIntensity : 0.05, // set text rgb intensity
  navTextsRgbIntensity : 15, // set text rgb intensity for regular nav

  textTitleColor : 'white', // title color
  textTitleSize : 80, // title size
  mobileTextTitleSize : 80, // title size
  textTitleLetterspacing : 2, // title letterspacing

  // textSubTitleColor : 'white', // subtitle color ex : 0x000000
  // textSubTitleSize : 21, // subtitle size
  // mobileTextSubTitleSize : 14,
  // textSubTitleLetterspacing : 3, // subtitle letter spacing
  // textSubTitleOffsetTop : 90, // subtitle offset top
  // mobileTextSubTitleOffsetTop : 40,
});